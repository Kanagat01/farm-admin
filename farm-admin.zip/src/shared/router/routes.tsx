export const LOGIN_ROUTE = "/login";
export const USERS_ROUTE = "/users";
export const PLANTED_SEEDS_ROUTE = "/planted_seeds";
export const PRINTERS_ROUTE = "/printers";
export const MARKETPLACE_ROUTE = "/marketplace";
export const ORDERS_ROUTE = "/orders";
export const LOGISTICS_ROUTE = "/logistics";
export const SUPPORT_MESSAGES_ROUTE = "/support_messages";

export const SUCCESS_PAYMENT_ROUTE = "/success_payment";
