export function NotAccessed() {
  return (
    <div className="table-title my-4">
      У вас нет разрешений на просмотр данного раздела. Выберите другой раздел
    </div>
  );
}
